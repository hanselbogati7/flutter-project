# Campus Connect — Flutter Login and Registration

A mobile interface assignment demonstrating Flutter widgets, layouts, forms,
password visibility, validation and navigation. The design uses a blue theme,
rounded form cards and a campus identity.

## Features

- Login page with application name, email, password and Login button.
- Show/hide controls for password fields.
- Forgot Password dialog with email validation.
- Separate registration page with full name, email, password and confirmation.
- Required-field, email-format, minimum-length and matching-password validation.
- Navigation to registration and back to login.
- Registration demo returns the entered email to the login page.
- Scrollable layout for smaller screens and the on-screen keyboard.

This is a UI demonstration. It does not create accounts, authenticate users,
store credentials or send password reset emails. Valid submissions display
honest demo feedback. A backend is outside this assignment's UI scope.

## Screenshots

Capture the actual running app and save the images under the paths below.
Screenshots are pending; they are not included in this source package.

| Login | Registration |
| --- | --- |
| Add `screenshots/login.png` | Add `screenshots/register.png` |

After capturing both images, replace the table above with:

```markdown
| Login | Registration |
| --- | --- |
| ![Login](screenshots/login.png) | ![Registration](screenshots/register.png) |
```

## Technologies used

- Flutter
- Dart
- Material Design 3
- Built-in Navigator, Form and TextFormField widgets

No third-party packages or image assets are required.

## How to run

Prerequisites: Flutter SDK, VS Code or Android Studio, and an Android emulator
or connected phone. Check the installation using `flutter doctor`.

This download contains the application source. Generate Flutter's platform
scaffolding once, before opening or submitting it as a complete project:

```bash
cd flutter_login_assignment
flutter create --project-name flutter_login_assignment --platforms=android,ios .
flutter pub get
```

The template command may create a default counter test at
`test/widget_test.dart`. Remove that generated counter test because this app
has no counter, or replace it with tests for these forms. Keep this README
if prompted to replace it.

Then run:

```bash
dart format lib
flutter analyze
flutter run
```

After the platform folders are committed, someone cloning the complete
repository only needs `flutter pub get` followed by `flutter run`.
iOS builds require macOS and Xcode; use Android on Windows.

## Source structure

```text
lib/
  main.dart
  pages/
    login_page.dart
    register_page.dart
  widgets/
    auth_layout.dart
    password_field.dart
  utils/
    validators.dart
screenshots/
pubspec.yaml
README.md
SUBMISSION.md
```

`main.dart` configures the theme and opening page. The page classes own and
dispose their text controllers. `PasswordField` owns its visibility state.
`AuthLayout` shares the visual layout, and `Validators` centralizes validation.
The registration route returns an email using `Navigator.pop`.

## Manual verification

- Empty login submission shows required-field errors.
- Incorrectly formatted email is rejected.
- Password visibility toggles without losing input.
- Create an account opens a separate registration screen.
- Empty name, invalid email and passwords below eight characters are rejected.
- Nonmatching confirmation is rejected, including after changing the password.
- Valid registration returns to login with the email filled in.
- Back button and Back to Login return without creating extra login routes.
- Forgot Password rejects invalid email and clearly reports demo behavior.
- Both pages scroll when the keyboard is open on a small device.

Flutter was unavailable in the preparation environment. These runtime checks
and real screenshots must be completed locally before submission.

## Learning references

- https://docs.flutter.dev/cookbook/forms/validation
- https://docs.flutter.dev/cookbook/navigation/navigation-basics
