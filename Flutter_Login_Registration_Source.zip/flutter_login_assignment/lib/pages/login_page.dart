import 'package:flutter/material.dart';
import '../utils/validators.dart';
import '../widgets/auth_layout.dart';
import '../widgets/password_field.dart';
import 'register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  void _login() {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    // UI assignment: validation does not authenticate a real account.
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Login form is valid. This demo has no authentication backend.'),
    ));
  }

  Future<void> _forgotPassword() async {
    final resetKey = GlobalKey<FormState>();
    String resetEmail = _email.text.trim();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Forgot password?'),
        content: Form(
          key: resetKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Enter your email to try the reset form. No email is sent in this UI demo.'),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: resetEmail,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                decoration: const InputDecoration(labelText: 'Email address'),
                validator: Validators.email,
                onSaved: (value) => resetEmail = value!.trim(),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              if (resetKey.currentState!.validate()) {
                resetKey.currentState!.save();
                Navigator.pop(dialogContext, true);
              }
            },
            child: const Text('Continue'),
          ),
        ],
      ),
    );
    if (!mounted || submitted != true) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Email validated. Password reset requires a connected backend.'),
    ));
  }

  Future<void> _openRegistration() async {
    FocusScope.of(context).unfocus();
    final email = await Navigator.push<String>(context,
      MaterialPageRoute(builder: (_) => const RegisterPage()));
    if (!mounted || email == null) return;
    _formKey.currentState!.reset();
    _email.text = email;
    _password.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Registration form validated. No account was created in this UI demo.'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      title: 'Welcome back',
      subtitle: 'Sign in and stay connected with your campus.',
      child: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              autocorrect: false,
              validator: Validators.email,
              decoration: const InputDecoration(labelText: 'Email address',
                prefixIcon: Icon(Icons.mail_outline)),
            ),
            const SizedBox(height: 16),
            PasswordField(controller: _password, validator: Validators.loginPassword,
              action: TextInputAction.done, onSubmitted: (_) => _login()),
            Align(alignment: Alignment.centerRight,
              child: TextButton(onPressed: _forgotPassword,
                child: const Text('Forgot Password?'))),
            const SizedBox(height: 8),
            FilledButton(onPressed: _login, child: const Text('Login')),
            const SizedBox(height: 20),
            const Text('New to Campus Connect?', textAlign: TextAlign.center),
            TextButton(onPressed: _openRegistration,
              child: const Text('Create an account')),
          ],
        ),
      ),
    );
  }
}
