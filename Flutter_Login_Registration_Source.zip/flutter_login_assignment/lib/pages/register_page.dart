import 'package:flutter/material.dart';
import '../utils/validators.dart';
import '../widgets/auth_layout.dart';
import '../widgets/password_field.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirmPassword = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirmPassword.dispose();
    super.dispose();
  }

  void _register() {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    // Return the email to LoginPage after validating the demo form.
    Navigator.pop(context, _email.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    return AuthLayout(
      showBack: true,
      title: 'Create your account',
      subtitle: 'Your campus community starts here.',
      child: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.next,
              validator: Validators.name,
              decoration: const InputDecoration(labelText: 'Full name',
                prefixIcon: Icon(Icons.person_outline)),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              autocorrect: false,
              validator: Validators.email,
              decoration: const InputDecoration(labelText: 'Email address',
                prefixIcon: Icon(Icons.mail_outline)),
            ),
            const SizedBox(height: 16),
            PasswordField(controller: _password, validator: Validators.newPassword),
            const SizedBox(height: 8),
            const Text('Use at least 8 characters.',
              style: TextStyle(color: Color(0xFF596579))),
            const SizedBox(height: 16),
            PasswordField(
              controller: _confirmPassword,
              label: 'Confirm password',
              action: TextInputAction.done,
              onSubmitted: (_) => _register(),
              validator: (value) {
                if (value == null || value.isEmpty) return 'Confirm your password';
                if (value != _password.text) return 'Passwords do not match';
                return null;
              },
            ),
            const SizedBox(height: 24),
            FilledButton(onPressed: _register, child: const Text('Create Account')),
            const SizedBox(height: 20),
            const Text('Already have an account?', textAlign: TextAlign.center),
            TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Back to Login')),
          ],
        ),
      ),
    );
  }
}
