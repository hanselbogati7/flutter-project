class Validators {
  static String? name(String? value) {
    if (value == null || value.trim().isEmpty) return 'Enter your full name';
    return null;
  }

  static String? email(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'Enter your email address';
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(text)) {
      return 'Enter a valid email address';
    }
    return null;
  }

  static String? loginPassword(String? value) {
    return value == null || value.isEmpty ? 'Enter your password' : null;
  }

  static String? newPassword(String? value) {
    if (value == null || value.isEmpty) return 'Create a password';
    if (value.length < 8) return 'Use at least 8 characters';
    return null;
  }
}
