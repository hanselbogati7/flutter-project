import 'package:flutter/material.dart';

// Shared layout keeps both pages consistent and scrollable with the keyboard.
class AuthLayout extends StatelessWidget {
  const AuthLayout({super.key, required this.title, required this.subtitle,
    required this.child, this.showBack = false});

  final String title;
  final String subtitle;
  final Widget child;
  final bool showBack;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: showBack ? AppBar(title: const Text('Registration')) : null,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Card(
                elevation: 0,
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Icon(Icons.school_rounded, size: 48,
                        color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 8),
                      const Text('CAMPUS CONNECT', textAlign: TextAlign.center,
                        style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
                      const SizedBox(height: 28),
                      Text(title, style: const TextStyle(fontSize: 28,
                        fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(subtitle, style: const TextStyle(color: Color(0xFF596579))),
                      const SizedBox(height: 24),
                      child,
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
