Place actual app screenshots here as login.png and register.png. No mock screenshots are included.
